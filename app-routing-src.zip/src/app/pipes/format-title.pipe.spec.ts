import { FormatTitlePipe } from './format-title.pipe';

describe('FormatTitlePipe', () => {
  it('create an instance', () => {
    const pipe = new FormatTitlePipe();
    expect(pipe).toBeTruthy();
  });
});
