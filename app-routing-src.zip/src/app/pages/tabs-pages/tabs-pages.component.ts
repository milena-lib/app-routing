import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabs-pages',
  templateUrl: './tabs-pages.component.html',
  styleUrls: ['./tabs-pages.component.css']
})
export class TabsPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
